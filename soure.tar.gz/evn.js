export const OSS_DEV_CONFIG = {
  region: 'oss-cn-beijing',
  accessKeyId: 'LTAI5tGQFtHeCiDAcDjMSTyv',
  accessKeySecret: '0BHACAf0r0KVUd9k2wwIDXZc6aFmx1',
  bucket: 'cloud-wedding',
};

export const DB_DEV_CONFIG = {
  host: 'localhost',
  port: 3306,
  username: 'root',
  password: 'lx123456',
  database: 'yunjian',
};
