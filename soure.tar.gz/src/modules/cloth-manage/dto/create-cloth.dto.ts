export class CreateClothDto {
  code: string;

  type: number;

  imgCode: string;

  num: number;

  totalNum: number;

  remark: string;
}
