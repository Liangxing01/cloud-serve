export const jwtConstants = {
  secret: 'Listen2me',
};
