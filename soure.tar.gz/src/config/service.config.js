export const serviceConfig = {
  cookieExpTime: 1000 * 60 * 60 * 3,
  ossPerfix: 'https://cloud-wedding.oss-cn-beijing.aliyuncs.com/wedding/',
};
